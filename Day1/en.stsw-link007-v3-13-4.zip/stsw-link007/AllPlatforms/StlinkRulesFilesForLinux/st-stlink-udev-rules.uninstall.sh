#!/bin/bash

set -e
rm -f /etc/udev/rules.d/{49-stlinkv1.rules,49-stlinkv2-1.rules,49-stlinkv2.rules,49-stlinkv3.rules}
